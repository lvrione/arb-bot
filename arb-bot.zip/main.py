
import requests
import time
from telegram import Bot

# Telegram bot token и chat_id
TELEGRAM_TOKEN = "7602973549:AAG2dP3RpeqAhzJ4wHnJjV4u-feidL_iCr8"
CHAT_ID = 445508386

bot = Bot(token=TELEGRAM_TOKEN)

def fetch_odds():
    # Заглушка: здесь должен быть парсинг сайтов Winline и Olimpbet
    # Возвращаем примерные данные
    return [
        {
            "match": "Алекс де Минор – Янник Синнер",
            "bookmaker1": {"name": "Winline", "outcome": "П1", "odds": 2.05},
            "bookmaker2": {"name": "Olimpbet", "outcome": "П2", "odds": 2.10}
        }
    ]

def calculate_arb(odds1, odds2):
    inv_sum = 1/odds1 + 1/odds2
    if inv_sum < 1:
        profit = (1 - inv_sum) * 100
        return profit
    return 0

def format_message(arb):
    match = arb["match"]
    bm1 = arb["bookmaker1"]
    bm2 = arb["bookmaker2"]
    profit = calculate_arb(bm1["odds"], bm2["odds"])
    stake1 = 1000 / bm1["odds"] / (1 / bm1["odds"] + 1 / bm2["odds"])
    stake2 = 1000 / bm2["odds"] / (1 / bm1["odds"] + 1 / bm2["odds"])
    profit_money = 1000 - stake1 - stake2
    msg = f"""🎾 Вилка найдена!
Матч: {match}
🏦 {bm1['name']}: {bm1['outcome']} — {bm1['odds']}
🏦 {bm2['name']}: {bm2['outcome']} — {bm2['odds']}
📊 Профит: +{profit:.2f}%
💸 Рекомендуемые ставки:
  • {bm1['name']} — {stake1:.0f} ₽
  • {bm2['name']} — {stake2:.0f} ₽
💰 Гарантированная прибыль: +{profit_money:.2f} ₽
"""
    return msg

def main():
    while True:
        odds_list = fetch_odds()
        for arb in odds_list:
            profit = calculate_arb(arb["bookmaker1"]["odds"], arb["bookmaker2"]["odds"])
            if profit >= 2:
                msg = format_message(arb)
                bot.send_message(chat_id=CHAT_ID, text=msg)
        time.sleep(300)  # проверять каждые 5 минут

if __name__ == "__main__":
    main()
